# Entry point for Grace System

if __name__ == '__main__':
    print('Running Grace System...')