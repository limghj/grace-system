
"""
🎯 Grace System Main Execution

- 1분봉 수집 (Toss API)
- 뉴스 필터링
- 전략 판단
- 결과 저장 (3D 구조)
"""

from grace.collector import collect_minute_data
from grace.news_filter import filter_news
from grace.judge import judge_stock
from grace.cube import save_to_cube

def main():
    tickers = ["VRAR", "PROK", "XAGE"]

    for ticker in tickers:
        df = collect_minute_data(ticker)
        news = filter_news(ticker)
        signal = judge_stock(ticker, df, news)
        save_to_cube(ticker, df, news, signal)

if __name__ == "__main__":
    main()
