
# 🧠 Grace 전략 판단 모듈 (Lite)
def judge_stock(ticker, df, news):
    # [TODO] RSI/거래량/뉴스 점수 기반 판단
    latest_volume = df['volume'].iloc[-1]
    if news['score'] > 85 and latest_volume > 40000:
        return "매수관심"
    else:
        return "관망"
