
# 📦 Grace 1분봉 수집 모듈 (Stub)
import pandas as pd
from datetime import datetime

def collect_minute_data(ticker):
    # [TODO] Toss API로 대체 예정
    data = {
        "timestamp": [datetime.utcnow().isoformat()],
        "open": [1.00],
        "high": [1.05],
        "low": [0.98],
        "close": [1.03],
        "volume": [50000]
    }
    df = pd.DataFrame(data)
    return df
