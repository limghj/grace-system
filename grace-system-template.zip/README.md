# Grace System Template

This is the base template for the Grace Trading System.